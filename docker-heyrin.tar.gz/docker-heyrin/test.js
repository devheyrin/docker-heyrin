const json = [
  {
    title: '범죄도시2',
    opening_date: '2022-05-18'
  },
  {
    title: '탑건:매버릭',
    opening_date: '2022-06-22'
  },
  {
    title: '한산: 용의 출현',
    opening_date: '2022-07-27'
  },
  {
    title: '공조2: 인터내셔날',
    opening_date: '2022-09-07'
  },
  {
    title: '헌트',
    opening_date: '2022-08-10'
  }
]

json.forEach((item) => {
	console.log(item);
	console.log(item.title);
	console.log(item.opening_date);
})
